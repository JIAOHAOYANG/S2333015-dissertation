# Load Packages
library(corrplot)

# Import Data
data <- read.csv("datasetAssignment2.csv")

sociological_data <- subset(data,select = c(capitalimmo2022,
                                            capitalimmo2017,
                                            revmoyfoy2022,
                                            revmoyfoy2017,
                                            revmoy2022,
                                            revmoy2017,
                                            ppropri2022,
                                            ppropri2017,
                                            popagglo2022,
                                            popagglo2017,
                                            pop2021,
                                            pop2017,
                                            perbac2022,
                                            perbac2017,
                                            persup2022,
                                            persup2017,
                                            pagri2022,
                                            pagri2017,
                                            pcadr2022,
                                            pcadr2017,
                                            pouvr2022,
                                            pouvr2017,
                                            pempl2022,
                                            pempl2017,
                                            pchom2022,
                                            pchom2017))

election_data <- subset(data,select = c(pvoixMACRON2017,
                                        pvoixMELENCHON2017,
                                        pvoixMLEPEN2017,
                                        pvoixHAMON2017,
                                        pvoixPOUTOU2017,
                                        pvoixARTHAUD2017,
                                        pvoixFILLON2017,
                                        pvoixMACRON2022,
                                        pvoixMELENCHON2022,
                                        pvoixMLEPEN2022,
                                        pvoixZEMMOUR2022,
                                        pvoixPOUTOU2022,
                                        pvoixARTHAUD2022,
                                        pvoixPECRESSE2022,
                                        pvoixJADOT2022))

data <- cbind(codecommune = data$codecommune,
              sociological_data,
              election_data)
rownames(data) <- data$codecommune
data <- data[,-1]

# Relationship between variables

# Correlation plot
corrplot(corr = cor(data,use = "pairwise.complete.obs"),
         method = "color",
         tl.cex = 0.5,
         order = "AOE")

par(mfrow = c(1,2))
plot(log(pvoixMELENCHON2022) ~ log(pvoixMELENCHON2017), 
     xlab = "proportion of votes in 2017",
     ylab = "proportion of votes in 2022",
     main = "Jean-Luc Mélenchon",
     data = data)
plot(log(pvoixPOUTOU2022) ~ log(pvoixPOUTOU2017), 
     xlab = "proportion of votes in 2017",
     ylab = "proportion of votes in 2022",
     main = "Philippe Poutou",
     data = data)

election_pca <- prcomp(x = na.omit(election_data),center = TRUE,scale. = TRUE)

par(mfrow = c(1,2))
plot(election_pca,type = "line",main = NULL)
biplot(election_pca,cex = 0.3)

# Predict the proportion of votes for Emmanuel Macron in 2022
model1 <- lm(pvoixMACRON2022 ~ popagglo2022, data = data)
model2 <- lm(pvoixMACRON2022 ~ popagglo2022 + pcadr2022, data = data)
model3 <- lm(pvoixMACRON2022 ~ popagglo2022 + pcadr2022 + revmoyfoy2022, data = data)

summary(model1)
summary(model2)
summary(model3)

pre1 <- predict(model1,
                newdata = data.frame(popagglo2022 = 50000),
                interval = "prediction")
pre2 <- predict(model2,
                newdata = data.frame(popagglo2022 = 50000, 
                                     pcadr2022 = 0.25),
                interval = "prediction")
pre3 <- predict(model3,
                newdata = data.frame(popagglo2022 = 50000, 
                                     pcadr2022 = 0.25,
                                     revmoyfoy2022 = 22000),
                interval = "prediction")

prediction <- data.frame(Scenario = c(1,2,3),
                         rbind(pre1,pre2,pre3))
rownames(prediction) <- NULL
colnames(prediction)[-1] <- c("Prediction","95% Lower","95% Upper")
prediction
